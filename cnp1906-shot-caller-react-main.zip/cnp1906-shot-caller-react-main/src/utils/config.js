export const CLIENT_PROGRAM_HOSTNAME = "shot-caller.herokuapp.com";
export const VIMEO_BASE_URL = "https://player.vimeo.com/video/";
export const FILE_SIZE = 5