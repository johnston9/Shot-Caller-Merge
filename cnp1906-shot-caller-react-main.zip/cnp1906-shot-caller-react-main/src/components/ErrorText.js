const ErrorText = ({ message }) => {
  return <div style={{ color: "#F95252", fontSize: "13px" }}>{message}</div>
}
export default ErrorText
