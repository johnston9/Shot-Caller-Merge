const useHostName = () => {
  const host = window.location.hostname
  return host
}
export default useHostName
